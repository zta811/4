const mongoose =require('mongoose')
const bodyParser = require('body-parser')

mongoose.connect('mongodb://localhost:27017/LAB4',{
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useCreateIndex: true,


})

const userschema = new mongoose.Schema({
username:{type:String},
password:{type:String},



})

const User =mongoose.model('User',userschema)

module.exports={User}

