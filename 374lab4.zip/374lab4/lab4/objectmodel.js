const mongoose =require('mongoose')

mongoose.connect('mongodb://localhost:27017/LAB4',{
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useCreateIndex: true,


})


const Objectchema =  mongoose.Schema({
    name:{type:String},
    
    
    
    
    })
    
    const Object =mongoose.model('Object',Objectchema)
    
    module.exports={Object}