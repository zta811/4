const { User } = require('./models')

const { Object } = require('./objectmodel')

const mongoose = require('mongoose')

const express = require ('express')





const app =express()




app.use(express.json())

var bodyParser = require('body-parser')
app.use(bodyParser.urlencoded({ extended: false }))

app.use(bodyParser.json())


app.get('/finduser',async(req,res)=>{
res.send('ok!')

})

app.post('/register',async(req,res)=>{ const user = await User.create({
username:req.body.username,
password:req.body.password,


   })
   
   
    res.send(user)
    
    })











app.listen(3578,()=>{
console.log('http://localhost:3578')

})