const mongoose =require('mongoose')

mongoose.connect("mongodb://localhost:27017/pr2", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
  useCreateIndex: true,
})
const objectschema = new mongoose.Schema({
    name:{type:String},
    creator:{type:String},
    done:{type:Boolean},
    cleared:{type:Boolean}
    

  })
  const Object = mongoose.model('Obejct',objectschema)
  
module.exports = { Object }

